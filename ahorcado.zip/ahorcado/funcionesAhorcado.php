<?php
session_start();


function elegirPalabra(){
    static $tpalabras = ["Madrid","Sevilla","Murcia","Malaga","Mallorca","Menorca"];
    
    $palabra = $tpalabras[array_rand($tpalabras)];
    
    return $palabra; // Devuelve una palabra al azar
}


function comprobarLetra($letra,$cadena){
    
    for($i=0; $i<strlen($cadena); $i++){
        if($cadena[$i]===$letra[$i]){
            str_replace('-', $letra[$i], $_SESSION['palabrausuario']);
            return true;
        }else{
            $_SESSION['fallos']--;
        }
        return false;
    }
 
}

/*
 * Devuelve una cadena donde aparecen las letras de la cadenapalabra en su posición si
 * cada letra se encuentra en la cadenaletras
 */

function generaPalabraconHuecos ( $cadenaletras, $cadenapalabra) { 
    
    $resu = $cadenapalabra;
    
    for ($i = 0; $i<strlen($resu); $i++){
        $resu[$i] = '-';
    }
    
    for ($i = 0; $i<count($cadenaletras); $i++){
        $posicion = strpos($cadenapalabra, cadenaletras[$i]);
        
            $resu[$posicion] = $cadenaletras[$i];

    }
  
    return $resu;
}
?>