<?php
    session_start();
    include_once 'funcionesAhorcado.php';
    
    if(!isset($_SESSION['palabrasecreta'])){
        
        $_SESSION['palabrasecreta'] = elegirPalabra();
        $_SESSION['fallos'] = 5;
        

    }
    
    
    if(isset($_POST['letra'])){
        
        $_SESSION['letrausuario'] .= $_POST['letra'];
        $letras = $_SESSION['letrausuario'];
        $cadena = $_SESSION['palabrasecreta'];
        $_SESSION['palabrausuario'] = generaPalabraconHuecos($letras, $_SESSION['palabrasecreta']);
        comprobarLetra($letras, $cadena);
    }

    echo "<h3>".$_SESSION['palabrausuario']."</h3>";
    echo "<h3>Te quedan ".$_SESSION['fallos']." oportunidades.</h3>";
    
    if($_SESSION['fallos'] === 0){
        echo "<h3>GAME OVER</<h3>";
    }
   
    //La sesión se elimina tras 30 segundos de inactividad
    $inactividad = 600;
    if(isset($_SESSION["timeout"])){
        
        $sessionTTL = time() - $_SESSION["timeout"];
        if($sessionTTL > $inactividad){
            session_destroy();
            header("Location: adivina.php");
        }
    }
    $_SESSION["timeout"] = time();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<title>Juego del ahorcado</title>
	<style type="text/css">

		.formulario{
			width:25%;
   			position: relative;
   			margin:0 auto;

		}

		form{
   			background-color:#E6E6E6;
   			border-style: outset;
   			padding: 2%;
		}
		h3{
			width:25%;
			position: relative;
   			margin:5% auto ;

		}
	 
	 	p{
	 		text-align:center;
	 	}
	</style>
	</head>
	<body>
		<h3>Juego del Ahorcado</h3>
		<div class="formulario">
		<form action="ahorcado.php" method="post">
			<p>LETRA</p><input type="text" max="1" min="1" maxlength="1" name="letra"><br>
			<input type="submit" name="enviar" value="ENVIAR">
		</form>
		</div>
	</body>
</html>